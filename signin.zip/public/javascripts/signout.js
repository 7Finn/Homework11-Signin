$(function () {
	$('.container').css('height', 450);
})